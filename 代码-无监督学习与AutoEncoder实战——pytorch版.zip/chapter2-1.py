#开始搞数据
from torch.utils.data import Dataset
from torch.utils.data import DataLoader

from torchvision import datasets
from torchvision.transforms import ToTensor, Lambda
#下载数据集    28*28=784
training_data = datasets.MNIST(root='./dataset_method_1', train=True, transform=ToTensor(), download=True)
test_data = datasets.MNIST(root='./dataset_method_1', train=False, transform=ToTensor(), download=False)
train_dataloader = DataLoader(training_data, batch_size=64, shuffle=True)
test_dataloader = DataLoader(test_data, batch_size=64, shuffle=True)

import matplotlib.pyplot as plt
figure = plt.figure()
img, label = training_data[100]
plt.title(label)
#squeeze函数把为1的维度去掉
plt.imshow(img.squeeze(), cmap="gray")
plt.show()

print(img.shape)










