from torch.utils.data import Dataset
from torch.utils.data import DataLoader

from torchvision import datasets
from torchvision.transforms import ToTensor, Lambda, Compose, Normalize
#下载数据集    28*28=784
img_transform = Compose([
    ToTensor(),
    Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
])
training_data = datasets.MNIST(root='./dataset_method_1', train=True, transform=ToTensor(), download=True)
test_data = datasets.MNIST(root='./dataset_method_1', train=False, transform=ToTensor(), download=False)
train_dataloader = DataLoader(training_data, batch_size=64, shuffle=True)
import torch.nn as nn
class AutoEncoder(nn.Module):
    def __init__(self):
        super(AutoEncoder, self).__init__()
        self.encoderConv = nn.Sequential(
            nn.Conv2d(1, 16, 3, stride=3, padding=1), # [16, 10, 10]
            nn.ReLU(True),
            nn.MaxPool2d(2), # [16, 5, 5]
            nn.Conv2d(16, 8, 3, stride=1, padding=1), # [8, 5, 5]
            nn.ReLU(True),
            nn.MaxPool2d(2), # [8, 2, 2]
        )
        self.decoderConv = nn.Sequential(
            nn.ConvTranspose2d(8, 16, 3, stride=2),  # [16, 5, 5]
            nn.ReLU(True),
            nn.ConvTranspose2d(16, 8, 5, stride=3, padding=1),  # [8, 15, 15]
            nn.ReLU(True),
            nn.ConvTranspose2d(8, 1, 2, stride=2, padding=1),  # [1, 28, 28]
            nn.ReLU(True)
        )
    def forward(self, x):
        x1 = self.encoderConv(x)
        x = self.decoderConv(x1)
        return x1, x

import torch
import torch.nn as nn
model = AutoEncoder().cuda()
criterion = nn.MSELoss()
learning_rate = 1e-3
optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate, weight_decay=1e-5)
epochs_num = 100

import cv2
import numpy as np
import random
def add_noise(image,prob):
    noise_out = np.zeros(image.shape,np.float)
    thres = 1 - prob
    for i in range(image.shape[0]):
        for j in range(image.shape[1]):
            rdn = random.random()
            if rdn < prob:
                noise_out[i][j] = random.random()
            elif rdn > thres:
                noise_out[i][j] = random.random()
            else:
                noise_out[i][j] = image[i][j]#其他情况像素点不变
    return noise_out #返回椒盐噪声和加噪图像

# 构建一个用于加噪声然后测试网络去噪效果的图像
trans1 = ToTensor()
img, label = test_data[0]
img = img.squeeze().numpy()
print(img.shape)
img2 = add_noise(img, 0.01)
import matplotlib.pyplot as plt
figure = plt.figure()
plt.title(label)
#squeeze函数把为1的维度去掉
plt.imshow(img2, cmap="gray")
plt.show()
img2 = trans1(img2)
img2 = img2.unsqueeze(dim=0).type(torch.FloatTensor).cuda()

#用来抽取测试数据的标志位
testdataGot = 0
from torch.autograd import Variable
import matplotlib.pyplot as plt
for epoch in range(epochs_num):
    model.train()
    for i, data in enumerate(train_dataloader):
        # ===================forward=====================
        output1, output = model(data[0].cuda())
        loss = criterion(output, data[0].cuda())
        # ===================backward====================
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        # 抽取第5个batch做测试
        if i == 5 & testdataGot==0:
            testdataGot = 1
            testdata = data[0].clone().cuda()
            print(testdata.shape)
    # ===================log========================
    print('epoch [{}/{}], loss:{:.4f}'.format(epoch+1, epochs_num, loss.data))
    model.eval()
    if epoch % 10 == 0:
        with torch.no_grad():
            figure = plt.figure()
            #print(testdata.shape)
            #print(img2.shape)
            outp2, outp = model(img2)
            print(outp.shape)
            adisplay = outp.cpu()
            # detach()去除梯度信息，然后再转换为numpy
            adisplay = adisplay.squeeze().detach().numpy()
            plt.imshow(adisplay, cmap="gray")
            plt.show()
        # 保存模型
        path = './model' + str(epoch) + '.pth'
        state = {'model': model.state_dict(), 'epoch': epoch}
        torch.save(state, path)

















