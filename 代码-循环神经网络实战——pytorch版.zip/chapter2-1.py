from torch.utils.data import Dataset
from torch.utils.data import DataLoader
from torchvision import datasets
from torchvision.transforms import ToTensor, Lambda
#数据集    28*28=784
training_data = datasets.MNIST(root='./myData', train=True, transform=ToTensor(), download=True)
test_data = datasets.MNIST(root='./myData', train=False, transform=ToTensor(), download=True)
train_dataloader = DataLoader(training_data, batch_size=64, shuffle=True)
test_dataloader = DataLoader(test_data, batch_size=64, shuffle=True)

"""
import matplotlib.pyplot as plt
figure = plt.figure()
img, label = training_data[100]
plt.title(label)
#squeeze函数把为1的维度去掉
plt.imshow(img.squeeze(), cmap="gray")
plt.show()
print(img.shape)
"""

import torch.nn as nn
class LSTM_Net(nn.Module):
    def __init__(self):
        super(LSTM_Net, self).__init__()
        self.RNNNet = nn.LSTM(
            input_size=28,
            hidden_size=64,
            num_layers=1,
            bias=True,
            batch_first=True,
        )
        self.linear = nn.Sequential(
            nn.Linear(64, 32),
            nn.ReLU(),
            nn.Linear(32, 10)
        )
    def forward(self, x):
        r_out, (h_n, h_c) = self.RNNNet(x, None)
        #print(r_out.shape)
        r_out = r_out[:, -1, :]
        #print(r_out.shape)
        out = self.linear(r_out)
        return out

rnn = LSTM_Net().cuda()
print(rnn)
import torch
optimizer = torch.optim.Adam(rnn.parameters(), lr=0.01)
loss_function = nn.CrossEntropyLoss()

epochs = 100
for epoch in range(epochs):
    rnn.train()
    for step, (x, y) in enumerate(train_dataloader):
        #print("")
        #print(x.shape)
        x = x.view(-1, 28, 28).cuda()
        #x = x.squeeze().cuda()
        y = y.cuda()
        #print(x.shape)
        #print(y.shape)
        #print("")
        output = rnn(x)
        loss = loss_function(output, y)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
    rnn.eval()
    with torch.no_grad():
        test_loss = 0
        correct = 0
        num_batches = len(test_dataloader)
        size = len(test_dataloader.dataset)
        for X, y in test_dataloader:
            X = X.view(-1, 28, 28).cuda()
            y = y.cuda()
            pred = rnn(X)
            test_loss += loss_function(pred, y).item()
            correct += (pred.argmax(1) == y).type(torch.float).sum().item()
        test_loss /= num_batches
        correct /= size
        print(f"Test Error: \n Accuracy: {(100 * correct):>0.1f}%, Avg loss: {test_loss:>8f} \n")




















