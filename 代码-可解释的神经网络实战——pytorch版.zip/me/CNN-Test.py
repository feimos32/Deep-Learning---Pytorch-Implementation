from torch.utils.data import Dataset
from torch.utils.data import DataLoader

from torchvision import datasets
from torchvision.transforms import ToTensor

import torch
import torch.nn as nn

from CNN import CNN_Net

if __name__ == '__main__':
    # 导入数据
    test_data = datasets.MNIST(root='./dataset_method_1', train=False, transform=ToTensor(), download=False)
    test_dataloader = DataLoader(test_data, batch_size=64, shuffle=True)
    # 恢复模型
    model = CNN_Net().cuda()
    checkpoint = torch.load('./model100.pth')
    model.load_state_dict(checkpoint ['model'] )
    epoch = checkpoint['epoch']
    # eval函数避免Dropout和BatchNormalization造成影响
    model.eval()
    test_acc = 0.0
    test_loss = 0.0
    loss = nn.CrossEntropyLoss()
    with torch.no_grad():
        for i, data in enumerate(test_dataloader):
            val_pred = model(data[0].cuda())
            batch_loss = loss(val_pred, data[1].cuda())
            test_acc += (val_pred.cpu().argmax(1) == data[1]).type(torch.float).sum().item()
            # val_acc += np.sum(np.argmax(val_pred.cpu().data.numpy(), axis=1) == data[1].numpy())
            test_loss += batch_loss.item()
        # 将结果 print 出來
        print('Val Acc: %3.6f loss: %3.6f' % \
              (test_acc / test_data.__len__(), test_loss / test_data.__len__()))

