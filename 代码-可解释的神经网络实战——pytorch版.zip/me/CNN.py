from torch.utils.data import Dataset
from torch.utils.data import DataLoader
from torchvision import datasets
from torchvision.transforms import ToTensor

import torch.nn as nn
class CNN_Net(nn.Module):
    def __init__(self):
        super(CNN_Net, self).__init__()
        self.Conv = nn.Sequential(
            nn.Conv2d(1, 32, 3, 1, 1),  # [32, 28, 28]
            # 对小批量（batch)1d（单通道）数据组成的4d输入进行标准化操作
            nn.BatchNorm2d(32),
            nn.ReLU(),
            nn.MaxPool2d(2, 2, 0),  # [32, 14, 14]

            nn.Conv2d(32, 16, 3, 1, 1),  # [16, 14, 14]
            nn.BatchNorm2d(16),
            nn.ReLU(),
            nn.MaxPool2d(2, 2, 0),  # [16, 7, 7]
        )
        self.Linear = nn.Sequential(
            nn.Linear(16*7*7, 256),
            nn.ReLU(),
            nn.Linear(256, 64),
            nn.ReLU(),
            nn.Linear(64, 10)
        )
    def forward(self, x):
        out = self.Conv(x)
        out = out.view(out.size()[0], -1)
        return self.Linear(out)

import torch

if __name__ == '__main__':

    # 加载数据
    training_data = datasets.MNIST(root='./dataset_method_1', train=True, transform=ToTensor(), download=True)
    test_data = datasets.MNIST(root='./dataset_method_1', train=False, transform=ToTensor(), download=False)
    train_dataloader = DataLoader(training_data, batch_size=64, shuffle=True)
    test_dataloader = DataLoader(test_data, batch_size=64, shuffle=True)

    model = CNN_Net().cuda()
    loss = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001)

    num_epoch = 101
    import time
    for epoch in range(num_epoch):
        epoch_start_time = time.time()
        train_acc = 0.0
        train_loss = 0.0
        test_acc = 0.0
        test_loss = 0.0
        #model.train()的作用是启用batch normalization和drop out
        model.train()
        for i, data in enumerate(train_dataloader):
            optimizer.zero_grad()
            # 利用 model 得到预测的概率分布
            train_pred = model(data[0].cuda()) #data[0]表示训练用的数据
            batch_loss = loss(train_pred, data[1].cuda())
            batch_loss.backward()
            optimizer.step()
            #argmax返回最大的索引值。因为最大值的索引就是分的类别。
            train_acc += (train_pred.cpu().argmax(1) == data[1]).type(torch.float).sum().item()
            #用numpy来判断是否正确
            #train_acc += np.sum(np.argmax(train_pred.cpu().data.numpy(), axis=1) == data[1].numpy())
            train_loss += batch_loss.item()
        if epoch % 10 == 0:
            path = './model' + str(epoch) + '.pth'
            state = {'model': model.state_dict(), 'epoch': epoch}
            torch.save(state, path)
        #在model(test_datasets)之前，需要加上model.eval(). 否则的话，有输入数据，即使不训练，它也会改变权值。
        model.eval()
        with torch.no_grad():
            for i, data in enumerate(test_dataloader):
                val_pred = model(data[0].cuda())
                batch_loss = loss(val_pred, data[1].cuda())
                test_acc += (val_pred.cpu().argmax(1) == data[1]).type(torch.float).sum().item()
                #val_acc += np.sum(np.argmax(val_pred.cpu().data.numpy(), axis=1) == data[1].numpy())
                test_loss += batch_loss.item()
            # 将结果 print 出來
            print('[%03d/%03d] %2.2f sec(s) Train Acc: %3.6f Loss: %3.6f | Val Acc: %3.6f loss: %3.6f' % \
                  (epoch + 1, num_epoch, time.time() - epoch_start_time, \
                   train_acc / training_data.__len__(), train_loss / training_data.__len__(), test_acc / test_data.__len__(),
                   test_loss / test_data.__len__()))














