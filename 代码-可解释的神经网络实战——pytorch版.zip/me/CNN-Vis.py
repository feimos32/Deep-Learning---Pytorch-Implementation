from torchvision import datasets
from torchvision.transforms import ToTensor

import torch
import torch.nn as nn
from torch.autograd import Variable

import os
import numpy as np

from PIL import Image

from CNN import CNN_Net

# 保存图像，单通道图保存为jpg
def save_image(img, path) -> None:
    img = img.transpose(1, 2, 0)
    img = np_arr = np.repeat(img, 3, axis=2)
    img = Image.fromarray(img)
    img.save(path)

# 把图像转换为float型可以用于训练的参数
def Img2Variable(img):
    im_as_arr = np.float32(img)
    # 转换为[通道数,图像宽,图像高]
    im_as_arr = im_as_arr.transpose(2, 0, 1)
    im_as_arr /= 255.0
    # 转换为 float tensor
    im_as_ten = torch.from_numpy(im_as_arr).float()
    # Add one more channel to the beginning. Tensor shape = 1,3,224,224
    im_as_ten.unsqueeze_(0)
    # Convert to Pytorch variable
    im_as_var = Variable(im_as_ten, requires_grad=True)
    return im_as_var

import copy
# 把用于训练的参数转换为图像
def Variable2Img(img_var):
    recreated_im = copy.copy(img_var.data.numpy()[0])
    recreated_im[recreated_im > 1] = 1
    recreated_im[recreated_im < 0] = 0
    recreated_im = np.round(recreated_im * 255)
    recreated_im = np.uint8(recreated_im)
    return recreated_im

class CNNLayerVisualization():
    def __init__(self, model, aim):
        self.model = model
        self.model.eval()
        # 我们要去最大化输出的目标
        self.aim = aim
        # 输出图像文件保存路径
        if not os.path.exists('./output'):
            os.makedirs('./output')

    def visualise_layer(self):
        # 生成一个随机图像，这里是28X28像素，数值为150到180之间的随机数
        random_image = np.uint8(np.random.uniform(150, 180, (28, 28, 1)))
        # 把图像转换为float型可以用于训练的参数
        imgInput = Img2Variable(random_image)
        # 定义优化器
        optimizer = torch.optim.Adam([imgInput], lr=0.1, weight_decay=1e-6)
        # 开始迭代
        for i in range(1, 1001):
            optimizer.zero_grad()
            x = imgInput.cuda()
            y = model(x)
            # 损失函数是 要激活的值 与 L2 正则化
            print(y)
            print(y.softmax(1))
            loss = (y.softmax(1) - aim.cuda()).abs().sum() + 0.003 * x.abs().sum()  + 0.01 * y.abs().sum()
            #print('Iteration:', str(i), 'Loss:', "{0:.2f}".format(-loss.data.cpu().numpy()))
            # 误差反向传播
            loss.backward()
            # 更新优化器
            optimizer.step()
            # Recreate image
            created_image = Variable2Img(imgInput.cpu())
            # Save image
            if i % 5 == 0:
                im_path = './output/iter ' + str(i) + '.jpg'
                save_image(created_image, im_path)


if __name__ == '__main__':
    # 从参数备份中恢复网络参数
    model = CNN_Net().cuda()
    checkpoint = torch.load('./model100.pth')
    model.load_state_dict(checkpoint ['model'] )
    # 定义我们想要最大化的输出结果
    aim = torch.from_numpy(np.array([[1,0,0,0,0,0,0,0,0,0]]))
    # 训练网络
    layer_vis = CNNLayerVisualization(model, aim)
    layer_vis.visualise_layer()




