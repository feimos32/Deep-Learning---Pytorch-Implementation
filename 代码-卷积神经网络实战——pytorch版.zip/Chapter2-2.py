import numpy as np
import torch
import torch.nn as nn
import torchvision.transforms as transforms
import cv2
import os
#总文件目录
data_dir = './food-11'
#根据路径读取图像数据文件
def readfile(path):
    image_dir = sorted(os.listdir(path))
    x = np.zeros((len(image_dir), 128, 128, 3), dtype=np.uint8)
    y = np.zeros((len(image_dir)), dtype=np.uint8)
    for i, file in enumerate(image_dir):
        img = cv2.imread(os.path.join(path, file))
        x[i, :, :] = cv2.resize(img, (128, 128))
        y[i] = int(file.split("_")[0])
    return x, y
#生成训练和验证数据集
train_x, train_y = readfile(os.path.join(data_dir, "training"))
val_x, val_y = readfile(os.path.join(data_dir, "validation"))

#print(train_x.shape)

from torch.utils.data import DataLoader, Dataset

class ImgDataset(Dataset):
    def __init__(self, x, y=None, transform=None):
        self.x = x
        # label is required to be a LongTensor
        self.y = y
        if y is not None:
            self.y = torch.LongTensor(y)  # 64bit有符号整形
        self.transform = transform
    def __len__(self):
        return len(self.x)
    def __getitem__(self, index):
        X = self.x[index]
        if self.transform is not None:
            X = self.transform(X)
        if self.y is not None:
            Y = self.y[index]
            return X, Y
        else:
            return X

# 这个类扩增数据：torch.utils.data
"""
torchvision.transforms.ToTensor
对一个img图片，调用ToTensor转化成张量的形式，发生的不是将图片的RGB三维信道矩阵变成tensor
图片在内存中以bytes的形式存储，转化过程的步骤是：
img.tobytes()  将图片转化成内存中的存储格式
torch.BytesStorage.frombuffer(img.tobytes() )  将字节以流的形式输入，转化成一维的张量
对张量进行reshape
对张量进行permute(2,0,1),张量的维度索引2变到位置0，索引0变到位置1，索引1变到位置2
将当前张量的每个元素除以255
输出张量

torchvision.transforms.ToPILImage
对于一个Tensor的转化过程是：
将张量的每个元素乘上255
将张量的数据类型有FloatTensor转化成Uint8
将张量转化成numpy的ndarray类型
对ndarray对象做permute (1, 2, 0)的操作
利用Image下的fromarray函数，将ndarray对象转化成PILImage形式
输出PILImage
"""
import torchvision.transforms as transforms
train_transform = transforms.Compose([
    transforms.ToPILImage(),
    transforms.RandomHorizontalFlip(),  # 隨機將圖片水平翻轉
    transforms.RandomRotation(15),  # 隨機旋轉圖片
    transforms.ToTensor(),  # 將圖片轉成 Tensor
])
# testing 時不需做 data augmentation(数据扩增)
test_transform = transforms.Compose([
    transforms.ToPILImage(),
    transforms.ToTensor(),
])

batch_size = 128
train_set = ImgDataset(train_x, train_y, train_transform)
val_set = ImgDataset(val_x, val_y, test_transform)
train_loader = DataLoader(train_set, batch_size=batch_size, shuffle=True)
val_loader = DataLoader(val_set, batch_size=batch_size, shuffle=False)


import matplotlib.pyplot as plt
"""
figure = plt.figure()
img, label = train_set[100]
img = img.squeeze().permute(1,2,0)
img = img[...,[2,1,0]]
plt.title(label)
#squeeze函数把为1的维度去掉
plt.imshow(img, cmap="gray")
plt.show()
"""

# torch.nn.Conv2d(in_channels, out_channels, kernel_size, stride, padding)
# torch.nn.MaxPool2d(kernel_size, stride, padding)
# input 维度 [3, 128, 128]
class Classifier(nn.Module):
    def __init__(self):
        super(Classifier, self).__init__()
        self.convolution = nn.Sequential(
            nn.Conv2d(3, 64, 3, 1, 1),  # [64, 128, 128]
            # 对小批量（batch)3d（加上通道数）数据组成的4d输入进行标准化操作
            nn.BatchNorm2d(64),
            nn.ReLU(),
            nn.MaxPool2d(2, 2, 0),  # [64, 64, 64]

            nn.Conv2d(64, 128, 3, 1, 1),  # [128, 64, 64]
            nn.BatchNorm2d(128),
            nn.ReLU(),
            nn.MaxPool2d(2, 2, 0),  # [128, 32, 32]

            nn.Conv2d(128, 256, 3, 1, 1),  # [256, 32, 32]
            nn.BatchNorm2d(256),
            nn.ReLU(),
            nn.MaxPool2d(2, 2, 0),  # [256, 16, 16]

            nn.Conv2d(256, 512, 3, 1, 1),  # [512, 16, 16]
            nn.BatchNorm2d(512),
            nn.ReLU(),
            nn.MaxPool2d(2, 2, 0),  # [512, 8, 8]

            nn.Conv2d(512, 512, 3, 1, 1),  # [512, 8, 8]
            nn.BatchNorm2d(512),
            nn.ReLU(),
            nn.MaxPool2d(2, 2, 0),  # [512, 4, 4]
        )
        self.fc = nn.Sequential(
            nn.Linear(512 * 4 * 4, 1024),
            nn.ReLU(),
            nn.Linear(1024, 512),
            nn.ReLU(),
            nn.Linear(512, 11)
        )
    def forward(self, x):
        out = self.convolution(x)
        #print(out.size())
        #print(out.size()[0])
        out = out.view(out.size()[0], -1)
        #print(out.size())
        return self.fc(out)


model = Classifier().cuda()
loss = nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(model.parameters(), lr=0.001)


num_epoch = 100
import time
for epoch in range(num_epoch):
    epoch_start_time = time.time()
    train_acc = 0.0
    train_loss = 0.0
    val_acc = 0.0
    val_loss = 0.0
    #model.train()的作用是启用batch normalization和drop out
    model.train()
    for i, data in enumerate(train_loader):
        optimizer.zero_grad()
        # 利用 model 得到预测的概率分布
        train_pred = model(data[0].cuda()) #data[0]表示训练用的数据
        batch_loss = loss(train_pred, data[1].cuda())
        batch_loss.backward()
        optimizer.step()
        #argmax返回最大的索引值。因为最大值的索引就是分的类别。
        train_acc += (train_pred.cpu().argmax(1) == data[1]).type(torch.float).sum().item()
        #用numpy来判断是否正确
        #train_acc += np.sum(np.argmax(train_pred.cpu().data.numpy(), axis=1) == data[1].numpy())
        train_loss += batch_loss.item()
    #在model(test_datasets)之前，需要加上model.eval(). 否则的话，有输入数据，即使不训练，它也会改变权值。
    model.eval()
    with torch.no_grad():
        for i, data in enumerate(val_loader):
            val_pred = model(data[0].cuda())
            batch_loss = loss(val_pred, data[1].cuda())
            val_acc += (val_pred.cpu().argmax(1) == data[1]).type(torch.float).sum().item()
            #val_acc += np.sum(np.argmax(val_pred.cpu().data.numpy(), axis=1) == data[1].numpy())
            val_loss += batch_loss.item()
        # 将结果 print 出來
        print('[%03d/%03d] %2.2f sec(s) Train Acc: %3.6f Loss: %3.6f | Val Acc: %3.6f loss: %3.6f' % \
              (epoch + 1, num_epoch, time.time() - epoch_start_time, \
               train_acc / train_set.__len__(), train_loss / train_set.__len__(), val_acc / val_set.__len__(),
               val_loss / val_set.__len__()))

















