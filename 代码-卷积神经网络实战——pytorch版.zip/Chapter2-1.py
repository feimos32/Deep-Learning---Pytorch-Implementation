import numpy as np
import torch
import torch.nn as nn
import torchvision.transforms as transforms
import cv2
import os
#总文件目录
data_dir = './food-11'
#根据路径读取图像数据文件
def readfile(path):
    image_dir = sorted(os.listdir(path))
    x = np.zeros((len(image_dir), 128, 128, 3), dtype=np.uint8)
    y = np.zeros((len(image_dir)), dtype=np.uint8)
    for i, file in enumerate(image_dir):
        img = cv2.imread(os.path.join(path, file))
        x[i, :, :] = cv2.resize(img, (128, 128))
        y[i] = int(file.split("_")[0])
    return x, y
#生成训练和验证数据集
train_x, train_y = readfile(os.path.join(data_dir, "training"))
val_x, val_y = readfile(os.path.join(data_dir, "validation"))

#print(train_x.shape)

from torch.utils.data import DataLoader, Dataset

class ImgDataset(Dataset):
    def __init__(self, x, y=None, transform=None):
        self.x = x
        # label is required to be a LongTensor
        self.y = y
        if y is not None:
            self.y = torch.LongTensor(y)  # 64bit有符号整形
        self.transform = transform
    def __len__(self):
        return len(self.x)
    def __getitem__(self, index):
        X = self.x[index]
        if self.transform is not None:
            X = self.transform(X)
        if self.y is not None:
            Y = self.y[index]
            return X, Y
        else:
            return X

# 这个类扩增数据：torch.utils.data
"""
torchvision.transforms.ToTensor
对一个img图片，调用ToTensor转化成张量的形式，发生的不是将图片的RGB三维信道矩阵变成tensor
图片在内存中以bytes的形式存储，转化过程的步骤是：
img.tobytes()  将图片转化成内存中的存储格式
torch.BytesStorage.frombuffer(img.tobytes() )  将字节以流的形式输入，转化成一维的张量
对张量进行reshape
对张量进行permute(2,0,1),张量的维度索引2变到位置0，索引0变到位置1，索引1变到位置2
将当前张量的每个元素除以255
输出张量

torchvision.transforms.ToPILImage
对于一个Tensor的转化过程是：
将张量的每个元素乘上255
将张量的数据类型有FloatTensor转化成Uint8
将张量转化成numpy的ndarray类型
对ndarray对象做permute (1, 2, 0)的操作
利用Image下的fromarray函数，将ndarray对象转化成PILImage形式
输出PILImage
"""
import torchvision.transforms as transforms
train_transform = transforms.Compose([
    transforms.ToPILImage(),
    transforms.RandomHorizontalFlip(),  # 隨機將圖片水平翻轉
    transforms.RandomRotation(15),  # 隨機旋轉圖片
    transforms.ToTensor(),  # 將圖片轉成 Tensor
])
# testing 時不需做 data augmentation(数据扩增)
test_transform = transforms.Compose([
    transforms.ToPILImage(),
    transforms.ToTensor(),
])

batch_size = 128
train_set = ImgDataset(train_x, train_y, train_transform)
val_set = ImgDataset(val_x, val_y, test_transform)
train_loader = DataLoader(train_set, batch_size=batch_size, shuffle=True)
val_loader = DataLoader(val_set, batch_size=batch_size, shuffle=False)


import matplotlib.pyplot as plt
"""
figure = plt.figure()
img, label = train_set[100]
img = img.squeeze().permute(1,2,0)
img = img[...,[2,1,0]]
plt.title(label)
#squeeze函数把为1的维度去掉
plt.imshow(img, cmap="gray")
plt.show()
"""







