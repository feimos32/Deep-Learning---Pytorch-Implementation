import torch
import numpy as np

def dataGenerate(data,label):
    for idata in data:
        if idata[0] < 0.5:
            # 把小于0.5的值压缩到 [0,1] 之间
            idata[0] = idata[0] * 2
            if idata[1] < 0.5:
                # 把小于0.5的值压缩到 [0,1] 之间
                idata[1] = idata[1] * 2
                label.append(0)
            else:
                # 把大于0.5的值压缩到 [4,5] 之间
                idata[1] = (idata[1] - 0.5) * 2.0 + 4.0
                label.append(1)
        else:
            # 把大于0.5的值压缩到 [4,5] 之间
            idata[0] = (idata[0] -0.5)*2.0 + 4.0
            if idata[1] < 0.5:
                # 把小于0.5的值压缩到 [0,1] 之间
                idata[1] = idata[1] * 2
                label.append(2)
            else:
                # 把大于0.5的值压缩到 [4,5] 之间
                idata[1] = (idata[1] - 0.5) * 2.0 + 4.0
                label.append(3)

data = np.random.rand(20000, 2)
label=[]
dataGenerate(data, label)
x_data = torch.tensor(data).float()
y_data = torch.tensor(label)
from torch.autograd import Variable
x_data,y_data = Variable(x_data),Variable(y_data)

data2 = np.random.rand(1000, 2)
label2=[]
dataGenerate(data2, label2)
x_data2 = torch.tensor(data2).float()
y_data2 = torch.tensor(label2)
x_data2,y_data2 = Variable(x_data2),Variable(y_data2)

import torch.nn as nn
class NeuralNetwork(nn.Module):
    def __init__(self):
      super(NeuralNetwork, self).__init__()
      # 把数组降到1维
      self.flatten = nn.Flatten()
      self.linear_relu_stack = nn.Sequential(
          nn.Linear(2, 7),
          nn.ReLU(),
          nn.Linear(7, 8),
          nn.ReLU(),
          nn.Linear(8, 4),
      )
    def weight_init(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                m.weight.data.normal_(0.0, 1.0)#.fill_(0.05)
                m.bias.data.zero_()
    def forward(self, x):
      #x = self.flatten(x)
      logits = self.linear_relu_stack(x)
      return logits

model = NeuralNetwork()
model.weight_init()

loss_function = nn.CrossEntropyLoss()
learning_rate = 1e-3
optimizer = torch.optim.SGD(model.parameters(), lr=learning_rate)

def train_loop(dataset, label, model, loss_function, optimizer):
    size = len(dataset)
    # Compute prediction and loss
    pred = model(dataset)
    loss = loss_function(pred, label)
    # Backpropagation
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()
    loss = loss.item()
    print(f"loss: {loss:>7f}")

correctCurve = []

def test_loop(dataset, label, model, loss_function):
    size = len(dataset)  # 10000
    test_loss, correct = 0, 0
    with torch.no_grad():
        for X,y in zip(dataset, label):
            pred = model(X)
            #print(pred.argmax(0))
            pred = torch.unsqueeze(pred, 0)
            y = torch.tensor([y])
            test_loss += loss_function(pred, y).item()
            correct += (pred.argmax(1) == y).type(torch.float).sum().item()
    test_loss /= size
    correct /= size
    correctCurve.append(correct * 100.0)
    print(f"Test Error: \n Accuracy: {(100*correct):>0.1f}%, Avg loss: {test_loss:>8f} \n")

epochs = 100
for t in range(epochs):
    print(f"Epoch {t+1}\n-------------------------------")
    train_loop(x_data, y_data, model, loss_function, optimizer)
    test_loop(x_data2, y_data2, model, loss_function)
print("Done!")


count = list(range(epochs))
count = [i + 1 for i in count]

import matplotlib.pyplot as plt
fig ,ax= plt.subplots()
ax.set_xlabel('count')
ax.set_ylabel('correct(%)')
plt.plot(count,correctCurve,color='red',linewidth=2.0,linestyle='-')
plt.show()
























