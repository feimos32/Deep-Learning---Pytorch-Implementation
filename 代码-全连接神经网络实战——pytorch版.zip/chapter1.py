import torch
import numpy as np

data1 = [[1, 2],[3, 4]]
data_tensor = torch.tensor(data1)
print(data_tensor.shape)
np_array1 = np.array(data1)
data_tensor = torch.from_numpy(np_array1)
print(data_tensor)
print(data_tensor.shape)

y = data_tensor @ data_tensor.T
print(y)
y = data_tensor * data_tensor
print(y)

np_array2 = data_tensor.numpy()
print(np_array2)


#开始搞数据
from torch.utils.data import Dataset
from torch.utils.data import DataLoader

from torchvision import datasets
from torchvision.transforms import ToTensor, Lambda

training_data = datasets.FashionMNIST(
    root="data",
    train=True, #用来训练的数据
    download=True, #如果根目录没有就下载
    transform=ToTensor()
    #, target_transform=Lambda(lambda y: torch.zeros(10, dtype=torch.float).scatter_(0, torch.tensor(y), value=1))
)
test_data = datasets.FashionMNIST(
    root="data",
    train=False, #用来测试的数据
    download=True, #如果根目录没有就下载
    transform=ToTensor()
    #, target_transform=Lambda(lambda y: torch.zeros(10, dtype=torch.float).scatter_(0, torch.tensor(y), value=1))
)
#把数据显示一下
labels_map = { 0: "T-Shirt", 1: "Trouser", 2: "Pullover", 3: "Dress", 4: "Coat",
    5: "Sandal", 6: "Shirt", 7: "Sneaker", 8: "Bag", 9: "Ankle Boot", }
import matplotlib.pyplot as plt
figure = plt.figure()
img, label = training_data[100]
plt.title(labels_map[label])
#squeeze函数把为1的维度去掉
plt.imshow(img.squeeze(), cmap="gray")
plt.show()

# batch_size：每次迭代取出的数据量
# shuffle：洗牌的意思，先把数据打乱，然后再分为不同的batch
train_dataloader = DataLoader(training_data, batch_size=64, shuffle=True)
test_dataloader = DataLoader(test_data, batch_size=64, shuffle=True)


train_features, train_labels = next(iter(train_dataloader))
print(f"Feature batch shape: {train_features.size()}")
print(f"Labels batch shape: {train_labels.size()}")
img = train_features[23].squeeze()
label = train_labels.numpy()[23]
plt.title(labels_map[label])
plt.imshow(img, cmap="gray")
plt.show()




