import torch
import numpy as np

#开始搞数据
from torch.utils.data import Dataset
from torch.utils.data import DataLoader

from torchvision import datasets
from torchvision.transforms import ToTensor, Lambda

training_data = datasets.FashionMNIST(
    root="data",
    train=True, #用来训练的数据
    download=True, #如果根目录没有就下载
    transform=ToTensor()
)
test_data = datasets.FashionMNIST(
    root="data",
    train=False, #用来测试的数据
    download=True, #如果根目录没有就下载
    transform=ToTensor()
)

# batch_size：每次迭代取出的数据量
# shuffle：洗牌的意思，先把数据打乱，然后再分为不同的batch
train_dataloader = DataLoader(training_data, batch_size=64, shuffle=True)
test_dataloader = DataLoader(test_data, batch_size=64, shuffle=True)



import torch.nn as nn
class NeuralNetwork(nn.Module):
    def __init__(self):
      super(NeuralNetwork, self).__init__()
      # 把数组降到1维
      self.flatten = nn.Flatten()
      self.linear_relu_stack = nn.Sequential(
          nn.Linear(28*28, 512),
          nn.ReLU(),
          nn.Linear(512, 512),
          nn.ReLU(),
          nn.Linear(512, 10),
      )
    def weight_init(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                #print(m.weight.shape)
                #print(m.bias.shape)
                m.weight.data.normal_(0.0, 1.0)#.fill_(0.05)
                m.bias.data.zero_()
                #print(m.weight)
                #print(m.bias)
    def forward(self, x):
      x = self.flatten(x)
      logits = self.linear_relu_stack(x)
      return logits

device = 'cuda' if torch.cuda.is_available() else 'cpu'
print(device)
model = NeuralNetwork().to(device)
model.weight_init()
print(model)

loss_function = nn.CrossEntropyLoss()
learning_rate = 1e-3
optimizer = torch.optim.SGD(model.parameters(), lr=learning_rate)

def train_loop(dataloader, model, loss_function, optimizer):
    size = len(dataloader.dataset) #训练集有60000个数据
    for batch, (X, y) in enumerate(dataloader):
        # Compute prediction and loss
        X = X.cuda()
        y = y.cuda()
        pred = model(X)
        loss = loss_function(pred, y)

        # Backpropagation
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        if batch % 100 == 0: #60000/64=937.5
            loss, current = loss.item(), batch * len(X)
            print(f"loss: {loss:>7f} batch:[{batch:>5d}] len(X):[{len(X)}] [{current:>5d}/{size:>5d}]")

def test_loop(dataloader, model, loss_function):
    size = len(dataloader.dataset)  # 10000
    print(f"size:{size}")  # 打印输出157（10000/64）
    num_batches = len(dataloader)
    print(f"num_batches:{num_batches}") # 打印输出157
    test_loss, correct = 0, 0

    with torch.no_grad():
        for X, y in dataloader:
            X = X.cuda()
            y = y.cuda()
            pred = model(X)
            test_loss += loss_function(pred, y).item()
            correct += (pred.argmax(1) == y).type(torch.float).sum().item()
            # print(f"len(X):[{len(X)}]")

    test_loss /= num_batches
    correct /= size
    print(f"Test Error: \n Accuracy: {(100*correct):>0.1f}%, Avg loss: {test_loss:>8f} \n")

""""""
epochs = 10
for t in range(epochs):
    print(f"Epoch {t+1}\n-------------------------------")
    train_loop(train_dataloader, model, loss_function, optimizer)
    test_loop(test_dataloader, model, loss_function)
print("Done!")








